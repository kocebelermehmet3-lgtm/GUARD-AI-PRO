# GUARD AI PRO

Yapay zeka destekli kamera ve güvenlik analiz sistemi.

## Özellikler
- Telefon kamerasını kullanma
- Tarayıcı üzerinde nesne/kişi tespiti
- Görüntü üzerinde tespit kutuları
- Olay geçmişi
- Kamera izin ve hata yönetimi
- Mobil uyumlu arayüz

## Çalıştırma
`index.html` dosyasını HTTPS üzerinden açın. Kamera erişimi için tarayıcı güvenli bağlantı (HTTPS) ister.

AI modeli tarayıcıda COCO-SSD kullanır ve model dosyaları CDN üzerinden yüklenir. İnternet bağlantısı yoksa AI tespiti çalışmayabilir.
