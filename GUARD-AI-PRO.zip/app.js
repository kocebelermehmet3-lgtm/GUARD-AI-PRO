const video=document.getElementById('camera'), canvas=document.getElementById('overlay'), ctx=canvas.getContext('2d');
const startBtn=document.getElementById('startBtn'), stopBtn=document.getElementById('stopBtn');
const statusEl=document.getElementById('status'), systemState=document.getElementById('systemState');
const modelState=document.getElementById('modelState'), detectCount=document.getElementById('detectCount');
const lastEvent=document.getElementById('lastEvent'), eventsList=document.getElementById('eventsList');
const placeholder=document.getElementById('placeholder'), notice=document.getElementById('notice');
let stream=null, model=null, running=false, lastDetection=0;

function notify(msg){notice.textContent=msg;notice.classList.remove('hidden');clearTimeout(notify.t);notify.t=setTimeout(()=>notice.classList.add('hidden'),3500)}
function addEvent(title, detail){const now=new Date().toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit',second:'2-digit'});lastEvent.textContent=title;const el=document.createElement('div');el.className='event';el.innerHTML=`<strong>${title}</strong><small>${detail} • ${now}</small>`;const empty=eventsList.querySelector('.empty');if(empty)empty.remove();eventsList.prepend(el)}
async function loadModel(){
  try{model=await cocoSsd.load();modelState.textContent='Hazır';}
  catch(e){modelState.textContent='Kullanılamıyor';notify('AI modeli yüklenemedi. İnternet bağlantısını kontrol et.');}
}
function resize(){if(video.videoWidth){canvas.width=video.videoWidth;canvas.height=video.videoHeight}}
async function detect(){
  if(!running||!model||video.readyState<2){requestAnimationFrame(detect);return}
  const predictions=await model.detect(video);
  ctx.clearRect(0,0,canvas.width,canvas.height);
  let humans=0;
  for(const p of predictions){
    if(p.score<0.55)continue;
    const [x,y,w,h]=p.bbox;ctx.strokeStyle='#55e6a5';ctx.lineWidth=3;ctx.strokeRect(x,y,w,h);
    ctx.fillStyle='#55e6a5';ctx.font='16px system-ui';ctx.fillText(`${p.class} %${Math.round(p.score*100)}`,x+4,Math.max(18,y+18));
    if(p.class==='person')humans++;
  }
  detectCount.textContent=predictions.filter(p=>p.score>=.55).length;
  if(humans>0 && Date.now()-lastDetection>5000){lastDetection=Date.now();addEvent('Kişi algılandı',`${humans} kişi`);}
  requestAnimationFrame(detect);
}
async function start(){
  try{
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'},audio:false});
    video.srcObject=stream;await video.play();resize();placeholder.style.display='none';running=true;
    statusEl.textContent='AKTİF';statusEl.className='status live';systemState.textContent='Kamera aktif';
    startBtn.disabled=true;stopBtn.disabled=false;addEvent('Kamera başlatıldı','Güvenlik izleme aktif');detect();
  }catch(e){notify('Kamera izni verilmedi veya kamera kullanılamıyor. Tarayıcı ayarlarından kamera iznini aç.');systemState.textContent='Kamera erişimi yok';statusEl.textContent='İZİN GEREKİYOR';statusEl.className='status warn'}
}
function stop(){
  running=false;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;video.srcObject=null;ctx.clearRect(0,0,canvas.width,canvas.height);
  placeholder.style.display='grid';startBtn.disabled=false;stopBtn.disabled=true;statusEl.textContent='HAZIR';statusEl.className='status idle';systemState.textContent='Hazır';addEvent('Kamera durduruldu','İzleme kapatıldı');
}
startBtn.onclick=start;stopBtn.onclick=stop;window.addEventListener('resize',resize);
document.getElementById('clearBtn').onclick=()=>{eventsList.innerHTML='<div class="empty">Henüz olay yok.</div>';lastEvent.textContent='—'};
loadModel();